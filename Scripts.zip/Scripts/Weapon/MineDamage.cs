﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MineDamage : MonoBehaviour
{
    [SerializeField] SphereCollider _explose;
    [SerializeField] float _explosiveRadiuse = 10f;
    [SerializeField] private int _damage = 5;
    float timer = 0.6f;
    bool activate = false;

    private void OnTriggerEnter(Collider other)
        {
        if(other.gameObject.CompareTag("Enemy"))
            {
            _explose.isTrigger = false;

            for(int i = 0; i <= _explosiveRadiuse; i++)
                _explose.radius = i;

            activate = true;
            }
        }

    private void OnCollisionEnter(Collision collision)
        {
        if(collision.gameObject.tag == "Enemy")
            {
            var enemy = collision.gameObject.GetComponent<MyEnemy>();
            enemy.Hurt(_damage);
            }
        }

    private void FixedUpdate()
        {
        if(activate)
            timer -= .2f;

        if(timer<=.2f)
            Destroy(gameObject);
        }
    }
