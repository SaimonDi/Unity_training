﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Miners : MonoBehaviour
{
    [SerializeField] float _expForce = 10f, _expRadius = 20f, _upwardsMod = 3f;
    [SerializeField] int _damage = 30;
    [SerializeField] float _lifetime = 60f;
    [SerializeField] LayerMask _layerMask;
    private Rigidbody _rb;
    private Coroutine LifeTime;


    private void Awake()
        {
        _rb = GetComponent<Rigidbody>();
        _rb.collisionDetectionMode = CollisionDetectionMode.Continuous;
        }

    private void OnCollisionEnter(Collision collision)
        {
        if(collision.collider.tag == "Map" && LifeTime == null)
            LifeTime = StartCoroutine(StopObj(collision.transform));

        if(collision.rigidbody != null && collision.rigidbody.tag == "Enemy")
            {
            Explosion();
            }
        
        }

    void Explosion()
        {
        Vector3 explosionPos = transform.position + Vector3.up * 2;
        Collider[] colliders = Physics.OverlapSphere(explosionPos, _expRadius, _layerMask);

        foreach(Collider hit in colliders)
            {
            if(hit is CapsuleCollider)
                {
                var enemy = hit.GetComponent<MyEnemy>();
                enemy.Hurt(_damage);
                enemy.Explosion(); //отключает NavMeshAgent и FreezeRotation на 3 сек чтобы не препятствовать взрыву

                Rigidbody enemy_rb = hit.GetComponent<Rigidbody>();
                if(enemy_rb != null)
                    enemy_rb.AddExplosionForce(_expForce, explosionPos, _expRadius, _upwardsMod, ForceMode.Impulse);
                }
            }
        Destroy(gameObject);
        }

    IEnumerator StopObj(Transform tr)
        {
        _rb.collisionDetectionMode = CollisionDetectionMode.Discrete;
        transform.SetParent(tr);
        transform.position = transform.position + transform.position.normalized * 0.05f;

        yield return new WaitForSeconds(_lifetime);

        if(LifeTime != null) { StopCoroutine(LifeTime); LifeTime = null; Destroy(gameObject); }
        }
    }
