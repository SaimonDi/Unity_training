﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RangeAttack : MonoBehaviour
{
    [SerializeField] int _damage, _force = 10;
    [SerializeField] float _lifetime = 5f;
    private Rigidbody _rb;
    private Coroutine LifeTime;


    private void Awake()
        {
        _rb = gameObject.GetComponent<Rigidbody>();
        _rb.collisionDetectionMode = CollisionDetectionMode.Continuous;
        }

    private void OnCollisionEnter(Collision collision)
        {
        if(collision.rigidbody != null && collision.rigidbody.tag == "Enemy")
            {
            if(LifeTime == null) LifeTime = StartCoroutine(StopObj(collision.transform));

            var enemy = collision.gameObject.GetComponent<MyEnemy>();
            enemy.Hurt(_damage);

            collision.rigidbody.AddForce(transform.position * _force, ForceMode.Impulse);
            }

        if(collision.collider.tag == "Map" && LifeTime == null)
            LifeTime = StartCoroutine(StopObj(collision.transform));
        }

    IEnumerator StopObj(Transform tr)
        {
        Destroy(_rb);
        gameObject.transform.SetParent(tr);
        transform.position = transform.position + transform.position.normalized * 0.05f;
        
        yield return new WaitForSeconds(_lifetime);

        if(LifeTime != null) { StopCoroutine(LifeTime); LifeTime = null; Destroy(gameObject); }
        }

}
