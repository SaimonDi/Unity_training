﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WeaponDamage : MonoBehaviour
{
    [SerializeField] private int _damage;
    [SerializeField] private bool _destroyHimSelf = false;
    private float waitTime = 20f;

    private void OnTriggerEnter(Collider other)
        {
        if(other is CapsuleCollider)
            if(other.gameObject.CompareTag("Enemy"))
                {
                var enemy = other.GetComponent<MyEnemy>();
                enemy.Hurt(_damage);
                }
        }

    private void FixedUpdate()
        {
        DestroyHimSelf();
        }

    private void DestroyHimSelf()
        {
        if(_destroyHimSelf)
            {
            if(waitTime >= .2f)
                waitTime -= .2f;
            if(waitTime <= .2f)
                Destroy(gameObject);
            }
        }
    }
