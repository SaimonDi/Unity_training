﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SecretDoor : MonoBehaviour
    {
    [SerializeField] private float _speedOpen = 10f;
    private Vector3 _secretDoor,_targetPos;
    private bool _openDoor=false;

    private void Start()
        {
        _secretDoor = gameObject.transform.position;
        _targetPos = new Vector3(_secretDoor.x - 15f, _secretDoor.y, _secretDoor.z);
        }

    private void OnTriggerEnter(Collider other)
        {
        _openDoor = true;
        }
    private void Update()
        {
        if(_openDoor)
            transform.position = Vector3.MoveTowards(transform.position, _targetPos, _speedOpen * Time.deltaTime);

        if((transform.position-_targetPos).magnitude<=0.2f)
            Destroy(gameObject);
        }
    }
