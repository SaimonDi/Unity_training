﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMove : MonoBehaviour
    {
    [SerializeField] private float _JumpPower = 7f;
    private float _speedRot;
    private Vector3 _direction;
    private Animator m_animator;
    private Rigidbody m_Rigidbody;
    Transform _jump;
    
    
    bool m_IsGrounded;
    float m_GroundCheckDistance;


    void Awake()
        {
        m_animator = GetComponent<Animator>();
        m_Rigidbody = GetComponent<Rigidbody>();
        _jump = GetComponent<Transform>();
        _speedRot = 180f;
        m_GroundCheckDistance = 0.1f;
        }

    void Update()
        {
        //Запись движения по траектории
        _direction.x = Input.GetAxis("Horizontal");
        _direction.z = Input.GetAxis("Vertical");

        //Поворот с камерой
        float y = Input.GetAxis("Mouse X") * _speedRot * Time.deltaTime;
        if(y != 0) transform.Rotate(0f, y, 0f);

        CheckIsGround();
        }

    void CheckIsGround()
        {
        RaycastHit hit;

        if(Physics.Raycast(transform.position + (Vector3.up * 0.1f), Vector3.down, out hit, m_GroundCheckDistance))
            m_IsGrounded = true;
        else
            m_IsGrounded = false;
        }

    private void FixedUpdate()
        {

        //Реализация движения привязанные к анимации
        float h = _direction.x;
        float v = _direction.z;

        if(h >= 0)
            m_animator.SetFloat("speedh", Math.Abs(h));
        else
            m_animator.SetFloat("speedh", -Math.Abs(h));

        if(v >= 0)
            m_animator.SetFloat("speedv", Math.Abs(v));
        else
            m_animator.SetFloat("speedv", -Math.Abs(v));

        Sprint();
        Jump();
        }

    private void Sprint() //Спринт
        {
        if(Input.GetKey(KeyCode.LeftShift))
            m_animator.SetBool("sprint", true);
        else
            m_animator.SetBool("sprint", false);
        }

    private void Jump()
        {
        if(Input.GetKey(KeyCode.Space) && m_IsGrounded)
            {
            m_Rigidbody.AddForce(_jump.up * _JumpPower * m_Rigidbody.mass, ForceMode.Impulse);
            }
        }
    }
