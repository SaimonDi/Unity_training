﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerAction : MonoBehaviour
    {
    [SerializeField] private Transform _shotLocation;

    [SerializeField] private GameObject _arrow; // Наша стрела
    [SerializeField] private int _forceArrowSpeed;

    [SerializeField] private GameObject _turret; // Наша турель
    [SerializeField] private int _forceTurretThrow;

    [SerializeField] private GameObject _bomb; // Наша мина
    [SerializeField] private int _forceMineThrow;

    [SerializeField] private GameObject _worldLight_1;
    [SerializeField] private GameObject _worldLight_2;
    private Light _light_1, _light_2;
    private bool _lightMode;


    private Transform Mcam;

    //private Transform shootSpawnPlace; // точка, где создается мина
    private void Awake()
        {
        Mcam = Camera.main.transform;
        _light_1 = _worldLight_1.GetComponent<Light>();
        _light_2 = _worldLight_2.GetComponent<Light>();
        _lightMode = true;
        }
    void Start()
        {
        }

    private void Update()
        {
        if(Input.GetButtonDown("Fire1"))
            ObjectThrow(_arrow,Quaternion.Euler(Mcam.rotation.eulerAngles), _forceArrowSpeed);

        if(Input.GetButtonDown("Fire2"))
            ObjectThrow(_turret, Quaternion.Euler(-90f,0f,0f), _forceTurretThrow);

        if(Input.GetButtonDown("Fire3"))
            ObjectThrow(_bomb, Quaternion.identity, _forceMineThrow);

        if(Input.GetKeyDown(KeyCode.L))
            {
            _light_1.enabled = _lightMode;
            _light_2.enabled = _lightMode;
            _lightMode = !_lightMode;
            }
        }

    private void ObjectThrow(GameObject obj, Quaternion quaternion, int force)
        {
        GameObject temp = Instantiate(obj, _shotLocation.position, quaternion);
        Rigidbody RB;
        RB = temp.GetComponent<Rigidbody>();
        RB.AddForce(Mcam.forward * force, ForceMode.Impulse);
        }

    }
