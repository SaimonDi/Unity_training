﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LongRangeAim : MonoBehaviour
{
    private GameObject _hitParticle;
    private ParticleSystem _muzzleFlash;

    [SerializeField] private GameObject prefab;

    private bool _fire = true;
    private int _currentBulletCount;
    [SerializeField] private int _bulletCount = 30;
    [SerializeField] private float _shootingDistance = 250f;
    [SerializeField] private int _damage = 20;
    [SerializeField] LayerMask _layerMask;
    
    private RaycastHit hit;
    private Ray ray;
    private Transform Mcam;

    //public GameObject Prefab { get => prefab; set => prefab = value; }

    private void Awake()
        {
        _fire = true;
        _currentBulletCount = _bulletCount;
        Mcam = Camera.main.transform;
        }

    void Start()
    {
        
    }
    private void Fire()
        {
        if(_currentBulletCount > 0 && _fire)
            {
            //Animation
            //_muzzleFlash.Play();
            _currentBulletCount--;
            ray = new Ray(Mcam.position, Mcam.forward);

            if(Physics.Raycast(ray, out hit, _shootingDistance, _layerMask))
                {
                if(hit.collider.tag == "Player")
                        return;
                if(hit.collider.tag == "Enemy" && hit.rigidbody.tag == "Enemy")
                    {
                    var enemy = hit.collider.GetComponent<MyEnemy>();
                    enemy.Hurt(_damage);
                    
                    Instantiate(prefab, hit.point+hit.normal * .01f, Quaternion.LookRotation(Mcam.transform.eulerAngles), hit.transform);
                    }
                if(hit.collider.tag == "Map")
                    {
                    Instantiate(prefab, hit.point, Quaternion.LookRotation(Mcam.transform.eulerAngles), hit.transform);
                    }

                //Create ParticalSystem
                }
            }
        }

    void Update()
    {
        Debug.DrawRay(Mcam.position, Mcam.forward * 50f, Color.red);

        if(Input.GetButtonDown("Fire1"))
            {
            Fire();
            }
    }
}
