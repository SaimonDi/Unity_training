﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerCameraController : MonoBehaviour
{
    private Camera _cam;
    private Transform _target;
    private Transform _player;

    [SerializeField] private bool m_LockCursor = false;
    [SerializeField] public float speedX = 360f;
    [SerializeField] public float speedY = 240f;
    [SerializeField] public float limitY = 50f;
    [SerializeField] public float minDistance = 1f;
    [SerializeField] public float hideDistance = 1.3f;

    public LayerMask obstacles, noPlayer;

    private float _maxDistance, _currentYRotation;
    private Vector3 _localPosition;
    private LayerMask _camOrigin;

    private Vector3 _position
        {
        get { return transform.position; }
        set { transform.position = value; }
        }

    private void Awake()
        {
        _cam = gameObject.GetComponent<Camera>();
        _player = GameObject.FindGameObjectWithTag("Player").transform;
        _target = GameObject.FindGameObjectWithTag("CameraTag").transform;
        
        }

    void Start()
        {
        LockCursor();

        _localPosition = _target.InverseTransformPoint(_position);
        _maxDistance = Vector3.Distance(_position, _target.position);
        _camOrigin = _cam.cullingMask;
        }

    private void LockCursor()
        {
        Cursor.lockState = m_LockCursor ? CursorLockMode.Locked : CursorLockMode.None;
        Cursor.visible = !m_LockCursor;
        }

    private void Update()
        {
        if(m_LockCursor && Input.GetMouseButtonUp(0))
            {
            Cursor.lockState = m_LockCursor ? CursorLockMode.Locked : CursorLockMode.None;
            Cursor.visible = !m_LockCursor;
            }
        }

    private void OnDisable()
        {
        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;
        }

    // Update is called once per frame
    private void LateUpdate()
        {
        _position = _target.TransformPoint(_localPosition);

        CameraRotation();
        ObstaclesReact();
        PlayerReact();

        _localPosition = _target.InverseTransformPoint(_position);
        }

    void CameraRotation()
        {
        var mx = Input.GetAxis("Mouse X");
        var my = Input.GetAxis("Mouse Y");

        if(my!=0)
            {
            var tmp = Mathf.Clamp(_currentYRotation + my *speedY * Time.deltaTime, -limitY, limitY);
            if(tmp!=_currentYRotation)
                {
                var rot = tmp - _currentYRotation;
                transform.RotateAround(_target.position, -transform.right, rot);
                _currentYRotation = tmp;
                }
            }
        if(mx!=0 && _player.rotation.y == 0)
            {
            transform.RotateAround(_target.position, Vector3.up, mx * speedX * Time.deltaTime);
            }
        transform.LookAt(_target);
        }

    private void ObstaclesReact()
        {
        var distance = Vector3.Distance(_position, _target.position);
        RaycastHit hit;

        if(Physics.Raycast(_target.position, transform.position - _target.position, out hit, _maxDistance, obstacles))
            {
            _position = hit.point;
            }
        else if(distance < _maxDistance && !Physics.Raycast(_position, -transform.forward, .1f, obstacles))
            {
            _position -= transform.forward * .05f;
            }
        }

    private void PlayerReact()
        {
        var distance = Vector3.Distance(_position, _target.position);
        if(distance < hideDistance)
            {
            _cam.cullingMask = noPlayer;
            }
        else
            {
            _cam.cullingMask = _camOrigin;
            }
        }
    }
