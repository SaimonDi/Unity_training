﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawner : MonoBehaviour
    {
    [SerializeField] private GameObject _enemy;
    [SerializeField] private int _maxEnemyCounter = 10, _randomMinimum = 3, _randomMaximum = 5;
    [SerializeField] private float _areaAroundSpawn = 10;
    [SerializeField] bool _isTrigger;
    private bool waitTrigger;
    private int enemyCounter;
    private Coroutine Spawn;

    IEnumerator SpawnEnemy(int count)
        {
            while(count > enemyCounter)
                {
                yield return new WaitForSeconds(Random.Range(_randomMinimum, _randomMaximum));
                Create(_enemy);
                enemyCounter++;
                }

            if(Spawn != null) { StopCoroutine(Spawn); Spawn = null; }
        }

    private void Awake()
        {
        enemyCounter = 0;
        if(_isTrigger) gameObject.GetComponent<BoxCollider>().enabled = true;
        else gameObject.GetComponent<BoxCollider>().enabled = false;
        }

    private void Start()
        {
        if(!_isTrigger && Spawn == null) Spawn = StartCoroutine(SpawnEnemy(_maxEnemyCounter));
        }

    GameObject Create(GameObject prefab)
        {
        float _x = transform.position.x, _z = transform.position.z;
        float x = Random.Range(_x - _areaAroundSpawn, _x + _areaAroundSpawn);
        float z = Random.Range(_z - _areaAroundSpawn, _z + _areaAroundSpawn);
        Vector3 pos = new Vector3(x, 1f, z);
        GameObject temp = Instantiate(prefab, pos, Quaternion.identity);
        return temp;
        }

    private void OnTriggerEnter(Collider other)
        {
        if(other.gameObject.CompareTag("Player"))
            if(Spawn == null) Spawn = StartCoroutine(SpawnEnemy(_maxEnemyCounter));
        }
    }
