﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class WaypointPatrol : MonoBehaviour
    {
    [SerializeField] private bool randomPoint;
    [SerializeField] private Transform[] waypoints;
    private NavMeshAgent navMeshAgent;
    private Animator animator;
    private Transform target;

    int _CurrentWaypointIndex;
    bool _findAHero;

    private void Awake()
        {
        navMeshAgent = gameObject.GetComponent<NavMeshAgent>();
        animator = gameObject.GetComponent<Animator>();
        }

    void Start()
        {
        if(waypoints.Length != 0 && navMeshAgent.enabled)
            navMeshAgent.SetDestination(waypoints[0].position);
        }

    void Update()
        {
        if(navMeshAgent.enabled && waypoints.Length != 0)
            Patrool();
        }

    private void ComeToPlayer()
        {
        transform.LookAt(target);

        if(navMeshAgent.remainingDistance <= navMeshAgent.stoppingDistance)
            {
            }
        else
            {
            navMeshAgent.SetDestination(target.position);
            }
        }


    public void Patrool()
        {

        if(randomPoint)
            if((navMeshAgent.hasPath || !navMeshAgent.isPathStale) 
                && navMeshAgent.remainingDistance <= navMeshAgent.stoppingDistance)
                {
                if(_findAHero)
                    ComeToPlayer();
                else
                    {
                    _CurrentWaypointIndex = Random.Range(0, waypoints.Length);
                    navMeshAgent.SetDestination(waypoints[_CurrentWaypointIndex].position);
                    }
                }
            else
            if((navMeshAgent.hasPath || !navMeshAgent.isPathStale) 
                && navMeshAgent.remainingDistance <= navMeshAgent.stoppingDistance)
                {
                if(_findAHero)
                    ComeToPlayer();
                else
                    {
                    _CurrentWaypointIndex = (_CurrentWaypointIndex + 1) % waypoints.Length;
                    navMeshAgent.SetDestination(waypoints[_CurrentWaypointIndex].position);
                    }
                }

        AnimationCont();
        }

    private void OnTriggerStay(Collider other)
        {
        if(other.gameObject.CompareTag("Player") && navMeshAgent.enabled)
            {
            navMeshAgent.ResetPath();
            target = other.GetComponent<Transform>();
            navMeshAgent.SetDestination(target.position);
            _findAHero = true;
            }
        }

    private void OnTriggerExit(Collider other)
        {
        if(other.gameObject.CompareTag("Player") && navMeshAgent.enabled)
            {
            navMeshAgent.ResetPath();
            if(navMeshAgent.enabled && waypoints.Length != 0) Patrool();
            _findAHero = false;
            }
        }
    private void AnimationCont()
        {
        if(navMeshAgent.enabled 
            && (navMeshAgent.hasPath || !navMeshAgent.isPathStale) 
            && navMeshAgent.remainingDistance >= navMeshAgent.stoppingDistance)
            animator.SetFloat("speedv", 1f);
        else if(navMeshAgent.enabled)
            animator.SetFloat("speedv", 0f);
        }
    }
