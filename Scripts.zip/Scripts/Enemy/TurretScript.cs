﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TurretScript : MonoBehaviour
    {
    [SerializeField] private int _health;
    [SerializeField] private int _damage;
    [SerializeField] float _shootingDistance;
    [SerializeField] LayerMask _layerMask;

    Coroutine Attacking;
    GameObject _trans;
    RaycastHit hit;
    Ray ray;

    private void Start()
        {
        }

    public void Hurt(int damage)
        {
        print("Ouch: " + damage);

        _health -= damage;

        if(_health <= 0)
            Die();
        }

    private void Die()
        {
        _health = 0;
        Destroy(gameObject);
        }

    private void OnTriggerEnter(Collider other)
        {
        if(other.gameObject.CompareTag("Enemy"))
            {
            _trans = other.gameObject;
            if(Attacking == null) StartCoroutine(AttackTurrent());
            }
        }

    private void OnTriggerExit(Collider other)
        {
        if(other.gameObject.CompareTag("Enemy"))
            _trans = null;
        }

    private void StartAttack()
        {
        ray = new Ray(transform.position + Vector3.up * 0.5f, -_trans.transform.InverseTransformPoint(transform.position) + Vector3.up * 2);
        
        if(Physics.Raycast(ray, out hit, _shootingDistance, _layerMask))
            {
            if(hit.collider.tag == "Enemy")
                {
                var enemy = hit.collider.GetComponent<MyEnemy>();
                enemy.Hurt(_damage);
                }
            //Create ParticalSystem
            }
        }

    IEnumerator AttackTurrent()
        {
        while(_trans != null)
            {
            StartAttack();
            yield return new WaitForSeconds(5f);
            }

        if(Attacking != null && _trans == null) { StopCoroutine(AttackTurrent()); Attacking = null; }
        }


    private void FixedUpdate()
        {
        if(_trans != null)
            Debug.DrawRay(transform.position + Vector3.up * 0.5f, -_trans.transform.InverseTransformPoint(transform.position) + Vector3.up * 2);
        }
    }
