﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class MyEnemy : MonoBehaviour
    {
    [SerializeField] private int _health;
    private Coroutine Expl;
    private NavMeshAgent navMashAgent;
    Rigidbody _rb;

    bool m_IsGrounded;
    float m_GroundCheckDistance;



    private void Awake()
        {
        navMashAgent = GetComponent<NavMeshAgent>();
        _rb = GetComponent<Rigidbody>();
        m_GroundCheckDistance = 0.1f;
        }

    public void Explosion()
        {
        if(Expl == null) Expl = StartCoroutine(BangPhisics());
        }

    IEnumerator BangPhisics()
        {
        navMashAgent.enabled = false;
        _rb.freezeRotation = false;

        while(!m_IsGrounded)
            {
            CheckIsGround();
            yield return new WaitForSeconds(2f);
            }

        navMashAgent.enabled = true;
        _rb.freezeRotation = true;
        navMashAgent.ResetPath();
        GetComponent<WaypointPatrol>().Patrool();

        if(Expl != null) { StopCoroutine(Expl); Expl = null; }
        }

    void CheckIsGround()
        {
        RaycastHit hit;

        if(Physics.Raycast(transform.position + (Vector3.up * 0.1f), Vector3.down, out hit, m_GroundCheckDistance))
            m_IsGrounded = true;
        else
            m_IsGrounded = false;
        }


    public void Hurt(int damage)
        {
        print("Ouch: " + damage);

        _health -= damage;

        if(_health <= 0)
            Die();
        }

    private void Die()
        {
        _health = 0;
        Destroy(gameObject);
        }
    }
